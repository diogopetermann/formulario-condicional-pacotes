<?php
/**
 * Plugin Name: Formulário condicional para pacotes (Contact Form 7)
 * Description: Campo condicional na escolha de pacotes nacionais e internacionais. Funciona apenas nas páginas configuradas nas opções do plugin.
 * Version: 1.2
 * Author: Diogo Petermann
 * Author URI: https://www.diogopetermann.com.br
 */

// Admin menu
add_action('admin_menu', function () {
    add_options_page('Formulário Condicional', 'Formulário Condicional', 'manage_options', 'formulario_condicional', 'fcp_render_options_page');
});

// Register settings
add_action('admin_init', function () {
    register_setting('fcp_settings_group', 'fcp_settings');
});

// Admin page content
function fcp_render_options_page()
{
    $options = get_option('fcp_settings');
    $rules = $options['rules'] ?? [];
    ?>
    <div class="wrap">
        <h1>Formulário Condicional para Pacotes</h1>
        <form method="post" action="options.php">
            <?php settings_fields('fcp_settings_group'); ?>

            <h2>Como usar:</h2>
            <ol>
                <li>No seu formulário do Contact Form 7, crie campos SELECT com os nomes indicados abaixo.</li>
                <li>Crie campos de texto que ficarão visíveis apenas quando os valores configurados forem selecionados.</li>
                <li>Envolva os campos de texto em containers com os IDs indicados e estilo <code>display:none</code> (ex: <code>&lt;div id=&quot;outros-container&quot; style=&quot;display:none;&quot;&gt;</code>).</li>
                <li>O script será executado apenas nas páginas com os IDs abaixo.</li>
            </ol>

            <table class="form-table">
                <tr valign="top">
                    <th esc_attr>IDs das páginas (separados por vírgula)</th>
                    <td><input type="text" name="fcp_settings[page_ids]" value="<?php echo esc_attr($options['page_ids'] ?? ''); ?>" /></td>
                </tr>
            </table>

            <h2>Condições</h2>
            <table id="fcp-conditions" class="form-table">
                <thead>
                <tr>
                    <th>Nome do campo SELECT</th>
                    <th>Valor que ativa</th>
                    <th>ID do container</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($rules as $index => $rule) : ?>
                    <tr>
                        <td><input type="text" name="fcp_settings[rules][<?php echo $index; ?>][select_name]" value="<?php echo esc_attr($rule['select_name'] ?? ''); ?>" /></td>
                        <td><input type="text" name="fcp_settings[rules][<?php echo $index; ?>][target_value]" value="<?php echo esc_attr($rule['target_value'] ?? ''); ?>" /></td>
                        <td><input type="text" name="fcp_settings[rules][<?php echo $index; ?>][container_id]" value="<?php echo esc_attr($rule['container_id'] ?? ''); ?>" /></td>
                        <td><button type="button" class="button fcp-remove">Remover</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p><button type="button" class="button" id="fcp-add-condition">Adicionar Condição</button></p>
            <?php submit_button(); ?>
        </form>
    </div>
    <script>
        document.getElementById('fcp-add-condition').addEventListener('click', function () {
            const tableBody = document.querySelector('#fcp-conditions tbody');
            const rowCount = tableBody.rows.length;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><input type="text" name="fcp_settings[rules][${rowCount}][select_name]" /></td>
                <td><input type="text" name="fcp_settings[rules][${rowCount}][target_value]" /></td>
                <td><input type="text" name="fcp_settings[rules][${rowCount}][container_id]" /></td>
                <td><button type="button" class="button fcp-remove">Remover</button></td>
            `;
            tableBody.appendChild(row);
        });

        document.addEventListener('click', function (e) {
            if (e.target && e.target.classList.contains('fcp-remove')) {
                e.target.closest('tr').remove();
            }
        });
    </script>
<?php }

// Add link to settings in plugins list
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_link = '<a href="options-general.php?page=formulario_condicional">Configurações</a>';
    array_unshift($links, $settings_link);
    return $links;
});

// Enqueue JS conditionally
add_action('wp_enqueue_scripts', function () {
    $options = get_option('fcp_settings');
    $page_ids = array_map('intval', array_map('trim', explode(',', $options['page_ids'] ?? '')));
    if (is_page($page_ids)) {
        wp_enqueue_script('fcp-js', plugin_dir_url(__FILE__) . 'formulario-condicional.js', [], '1.2', true);
        wp_localize_script('fcp-js', 'fcpRules', $options['rules'] ?? []);
    }
});
