document.addEventListener('DOMContentLoaded', function () {
  const selectField = document.querySelector(`select[name="${fcpVars.selectName}"]`);
  const outrosContainer = document.getElementById(fcpVars.containerId);

  if (selectField && outrosContainer) {
    selectField.addEventListener('change', function () {
      if (selectField.value === fcpVars.targetValue) {
        outrosContainer.style.display = 'block';
      } else {
        outrosContainer.style.display = 'none';
      }
    });
  }
});
